const quizData = {
  title: "Quize app Application"
};

const questions = [
  {
    "text": "What is the capital of Japan?",
    "type": "mc",
    "answers": [
      {"text": "Tokyo", "correct": true},
      {"text": "Beijing", "correct": false},
      {"text": "Seoul", "correct": false},
      {"text": "Bangkok", "correct": false}
    ]
  },
  {
    "text": "Who painted the Mona Lisa?",
    "type": "mc",
    "answers": [
      {"text": "Leonardo da Vinci", "correct": true},
      {"text": "Vincent van Gogh", "correct": false},
      {"text": "Pablo Picasso", "correct": false},
      {"text": "Michelangelo", "correct": false}
    ]
  },
  {
    "text": "Which planet is known as the Red Planet?",
    "type": "mc",
    "answers": [
      {"text": "Mars", "correct": true},
      {"text": "Jupiter", "correct": false},
      {"text": "Venus", "correct": false},
      {"text": "Mercury", "correct": false}
    ]
  },
  {
    "text": "What is the largest mammal?",
    "type": "mc",
    "answers": [
      {"text": "Blue Whale", "correct": true},
      {"text": "African Elephant", "correct": false},
      {"text": "Giraffe", "correct": false},
      {"text": "Hippopotamus", "correct": false}
    ]
  },
  {
    "text": "Who was the first woman to win a Nobel Prize?",
    "type": "mc",
    "answers": [
      {"text": "Marie Curie", "correct": true},
      {"text": "Mother Teresa", "correct": false},
      {"text": "Rosalind Franklin", "correct": false},
      {"text": "Ada Lovelace", "correct": false}
    ]
  },
  {
    "text": "What is the chemical symbol for water?",
    "type": "mc",
    "answers": [
      {"text": "H2O", "correct": true},
      {"text": "CO2", "correct": false},
      {"text": "NaCl", "correct": false},
      {"text": "O2", "correct": false}
    ]
  },
  {
    "text": "Who wrote 'Romeo and Juliet'?",
    "type": "mc",
    "answers": [
      {"text": "William Shakespeare", "correct": true},
      {"text": "Charles Dickens", "correct": false},
      {"text": "Jane Austen", "correct": false},
      {"text": "Mark Twain", "correct": false}
    ]
  },
  {
    "text": "What is the tallest mountain in the world?",
    "type": "mc",
    "answers": [
      {"text": "Mount Everest", "correct": true},
      {"text": "K2", "correct": false},
      {"text": "Kangchenjunga", "correct": false},
      {"text": "Makalu", "correct": false}
    ]
  },
  {
    "text": "Which country is known as the Land of the Rising Sun?",
    "type": "mc",
    "answers": [
      {"text": "Japan", "correct": true},
      {"text": "China", "correct": false},
      {"text": "Korea", "correct": false},
      {"text": "India", "correct": false}
    ]
  },
  {
    "text": "Who invented the telephone?",
    "type": "mc",
    "answers": [
      {"text": "Alexander Graham Bell", "correct": true},
      {"text": "Thomas Edison", "correct": false},
      {"text": "Nikola Tesla", "correct": false},
      {"text": "Guglielmo Marconi", "correct": false}
    ]
  },
  {
    "text": "What is the currency of Brazil?",
    "type": "mc",
    "answers": [
      {"text": "Brazilian Real", "correct": true},
      {"text": "Peso", "correct": false},
      {"text": "Euro", "correct": false},
      {"text": "Dollar", "correct": false}
    ]
  },
  {
    "text": "Who is known as the Father of Computers?",
    "type": "mc",
    "answers": [
      {"text": "Charles Babbage", "correct": true},
      {"text": "Alan Turing", "correct": false},
      {"text": "Ada Lovelace", "correct": false},
      {"text": "Steve Jobs", "correct": false}
    ]
  },
  {
    "text": "Which is the largest ocean?",
    "type": "mc",
    "answers": [
      {"text": "Pacific Ocean", "correct": true},
      {"text": "Atlantic Ocean", "correct": false},
      {"text": "Indian Ocean", "correct": false},
      {"text": "Arctic Ocean", "correct": false}
    ]
  },
  {
    "text": "Who discovered penicillin?",
    "type": "mc",
    "answers": [
      {"text": "Alexander Fleming", "correct": true},
      {"text": "Louis Pasteur", "correct": false},
      {"text": "Marie Curie", "correct": false},
      {"text": "Albert Einstein", "correct": false}
    ]
  },
  {
    "text": "What is the chemical symbol for gold?",
    "type": "mc",
    "answers": [
      {"text": "Au", "correct": true},
      {"text": "Ag", "correct": false},
      {"text": "Fe", "correct": false},
      {"text": "Cu", "correct": false}
    ]
  },
  {
    "text": "Who painted 'Starry Night'?",
    "type": "mc",
    "answers": [
      {"text": "Vincent van Gogh", "correct": true},
      {"text": "Pablo Picasso", "correct": false},
      {"text": "Leonardo da Vinci", "correct": false},
      {"text": "Claude Monet", "correct": false}
    ]
  },
  {
    "text": "What is the main ingredient in guacamole?",
    "type": "mc",
    "answers": [
      {"text": "Avocado", "correct": true},
      {"text": "Tomato", "correct": false},
      {"text": "Onion", "correct": false},
      {"text": "Garlic", "correct": false}
    ]
  },
  {
    text: "What is my favourite place ?",
    type: "mc",
    answers: [
      { text: "Delhi", correct: false },
      { text: "Maligram,pingla", correct: true },
      { text: "Kolkata", correct: false },
      { text: "Mumbai", correct: false }
    ]
  }

];

module.exports = { quizData, questions };
